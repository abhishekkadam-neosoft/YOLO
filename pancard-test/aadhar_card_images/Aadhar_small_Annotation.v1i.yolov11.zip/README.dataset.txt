# Aadhar_small_Annotation > 2024-09-13 5:27am
https://universe.roboflow.com/ngin-xoern/aadhar_small_annotation

Provided by a Roboflow user
License: MIT

